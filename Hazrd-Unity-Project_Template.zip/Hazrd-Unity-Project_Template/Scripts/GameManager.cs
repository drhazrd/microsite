using System;
using UnityEngine;

public class GameManager: MonoBehaviour{
    
    public GameState currentState {get; private set;}
    int currentScore{get; private set;}
    float gameTime{get; private set;}
    int playerLives;
    int difficulty;
    /*
    win-LoseState
    */
    void StartGame(){}
    void PauseGame(){}
    void ResumeGame(){}
    void WinGame(){}
    void LoseGame(){}
    void RestartLevel(){}
    void QuitToMenu(){}

    public enum GameState{
        Menu,
        Loading,
        Playing,
        Paused,
        Won,
        Lost,
        Credits
    }
}