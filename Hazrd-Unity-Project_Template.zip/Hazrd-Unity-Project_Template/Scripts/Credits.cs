using System;
using UnityEngine;

public class Credits: MonoBehaviour{
    /*
    ["Programming - Nick", "Art - Nick", "Audio - Nick"]
    */
}