using System;
using UnityEngine;
using UnityEngine.SceneManager;

public class SceneManager: MonoBehaviour{
    /*
    laoding bar
    loading text //(update with time)
    loading info/tip list (Did you know...Press Space to Jump)
    
    */
    void LoadScene(string scene){
        SceneManager.LoadScene(scene);
    }
    void FadeOut(){
        
    }
    void FadeIn(){

    }
}