using System;
using UnityEngine;

public class SaveManager: MonoBehaviour{
    /*
        {
    "highscore":52,
    "music":0.8,
    "sfx":0.9
    }
    */

    void Save(){}
    void Load(){}
    void Delete(){}
}