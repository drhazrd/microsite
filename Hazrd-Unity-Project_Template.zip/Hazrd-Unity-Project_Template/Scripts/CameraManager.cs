using System;
using UnityEngine;

public class CameraManager: MonoBehaviour{
    
    
    Transform followTarget;
    /*
    Screen Shake
    Zoom
    Bounds
    */

    void Shake(){

    }
    void Zoom(){

    }
    void Follow(){

    }
}