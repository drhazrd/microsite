using System;
using UnityEngine;

public class ObjectPool: MonoBehaviour{
    /*
    Bullets
    Particles
    Enemies
    Pickups
    */

    void Spawn(){}
    void Return(){}
}