using System;
using UnityEngine;

public class AudioManager: MonoBehaviour{
    /*
    Music
    SFX
    UI
    Ambience
    */
    public static AudioManager audioSystem;

    void Awake(){
        audioSystem = this;
    }

    void PlaySound(){}
    void StopSound(){}
    void PlayMusic(){}
    void FadeMusic(){}
}