using System;
using UnityEngine;

public class UIManager: MonoBehaviour{
    /*
    
    */
        void ShowMenu(){}
    void HideMenu(){}
    void ShowPopup(){}
    void ShowPause(){}
    void ShowWin(){}
    void ShowLose(){}
}