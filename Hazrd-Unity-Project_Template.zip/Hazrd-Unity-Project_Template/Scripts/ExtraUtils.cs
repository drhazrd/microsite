using System;
using UnityEngine;

public class EventBus: MonoBehaviour{
    public void RandomChoice(){}
    public void RandomBool(){}
    public void RandomDirection(){}
    public void RandomPosition(){}
    public void DestroyAfter(){}
    public void SetAlpha(){}
    public void ResetTransforma(){}
}