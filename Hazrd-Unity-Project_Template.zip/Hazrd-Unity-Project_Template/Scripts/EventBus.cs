using System;
using UnityEngine;

public class EventBus: MonoBehaviour{
    /*
    Player Died
    ↓
    Event
    ↓
    UI Updates
    Audio Plays
    Game Ends
    */
    

}