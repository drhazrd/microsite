using System;
using UnityEngine;

public class DebugScreen: MonoBehaviour{
    /*
    FPS
    Player Position
    Game State
    Enemy Count

    Show with F1
    */    
}