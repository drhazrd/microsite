Hazrd Game Jam Kit

Bootstrap Scene

GameManager
SceneLoader
SaveManager
AudioManager
InputManager
UIManager

Loading Screen
Main Menu
Credits Screen
End Screen

Pause Menu

Object Pool

Camera Controller

Debug Overlay

Utility Library




To Use the Game:
The API works like:

GameManager.StartGame();
SceneLoader.Load("Level01");
AudioManager.PlaySFX("Click");
SaveManager.Save();