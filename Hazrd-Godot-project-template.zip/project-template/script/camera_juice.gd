extends Node

var offset : Vector2
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func Follow():
	pass
func Zoom():
	pass
func Shake(amount := 10.0):
	offset = Vector2(
		randf_range(-amount, amount),
		randf_range(-amount, amount)
	)
