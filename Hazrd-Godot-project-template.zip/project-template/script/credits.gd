extends Node

@export var timeSelection := 3.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	timeToEnd(timeSelection)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func timeToEnd(time):
	await get_tree().create_timer(time)
