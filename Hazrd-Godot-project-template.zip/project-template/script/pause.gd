extends Node
var isPaused := false
@onready var mainMenu := $Main
@onready var settingsMenu := $Settings
@onready var quitConfirmation := $QuitConfirm

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _input(event):
	if event.is_action_pressed("pause"):
		toggle_pause()

func toggle_pause():
	get_tree().paused = !get_tree().paused
	if isPaused:
		isPaused = false
	else:
		isPaused = true

func _on_quit_button_button_down() -> void:
	quitGame()
func openSettings():
	pass
func openMain():
	pass
func quitGame():
	load("res://scenes/MainMenu.tscn")
	
