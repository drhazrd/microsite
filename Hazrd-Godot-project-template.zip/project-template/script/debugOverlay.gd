extends Node

@export var debugText : Label


func _ready() -> void:
	pass # Replace with function body.

func _process(delta: float) -> void:
	if (debugText != null):
		var fpsCount = Engine.get_frames_per_second()
		#debugText.text = "FPS: " + str(fpsCount) + "Objects: " + str() + "Score: " + str() + "State: " + str()
