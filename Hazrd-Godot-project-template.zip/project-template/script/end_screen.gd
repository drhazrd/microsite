extends Node

var lastLevel = "res://scenes/MainMenu.tscn"
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Checck for the last level to load.
	loadNewScene(lastLevel)

func restartScene():
	get_tree().reload_current_scene()

func loadNewScene(newScene):
	load(newScene)
