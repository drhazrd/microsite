extends Node

var defaultLevel := "res://scenes/GameScene.tscn"
var levelToLoad := ""
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	levelToLoad = defaultLevel

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func loadLevel(levelLocation):
	print (levelLocation)
	load(levelLocation)
	get_tree().change_scene_to_file(levelLocation)
func quitGame():
	get_tree().quit()


func _on_start_button_button_down() -> void:
	print ("Press ed")
	loadLevel(levelToLoad)


func _on_settings_button_button_down() -> void:
	print ("Press ed")
	pass # Replace with function body.


func _on_quit_button_button_down() -> void:
	quitGame()
