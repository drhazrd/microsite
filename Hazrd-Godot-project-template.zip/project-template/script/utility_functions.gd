extends Node


# Called when the node enters the scene tree for the first time.
static func random_choice(array):
	return array.pick_random()

static func random_direction():
	return Vector2(
		randf_range(-1,1),
		randf_range(-1,1)
	).normalized()

static func chance(percent):
	return randf() < percent
