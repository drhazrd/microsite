extends Node

const SAVE_PATH = "user://save.json"

var data = {
	"highscore": 0
}

func save():
	var file = FileAccess.open(
		SAVE_PATH,
		FileAccess.WRITE
	)

	file.store_string(JSON.stringify(data))

func load_save():
	if !FileAccess.file_exists(SAVE_PATH):
		return

	var file = FileAccess.open(
		SAVE_PATH,
		FileAccess.READ
	)

	data = JSON.parse_string(
		file.get_as_text()
	)
