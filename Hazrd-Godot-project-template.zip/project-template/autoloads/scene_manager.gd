extends Node

var current_scene_path := ""

func load_scene(path:String):
	current_scene_path = path
	get_tree().change_scene_to_file(path)

func reload_current_scene():
	load_scene(current_scene_path)
