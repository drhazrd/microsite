extends Node

signal player_died
signal score_changed
signal game_won
