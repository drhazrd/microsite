extends Node

var music_player := AudioStreamPlayer.new()
var sfx_player := AudioStreamPlayer.new()

func _ready():
	add_child(music_player)
	add_child(sfx_player)

func play_sfx(sound):
	sfx_player.stream = sound
	sfx_player.play()

func play_music(sound):
	music_player.stream = sound
	music_player.play()
