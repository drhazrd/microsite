extends Node

enum State {
	MENU,
	LOADING,
	PLAYING,
	PAUSED,
	WIN,
	LOSE
}

var state := State.MENU
var score := 0

func start_game():
	score = 0
	SceneManager.load_scene("res://scenes/GameScreen")

func win():
	state = State.WIN
	SceneManager.load_scene("res://scenes/end_screen.tscn")

func lose():
	state = State.LOSE
	SceneManager.load_scene("res://scenes/end_screen.tscn")

func retry():
	SceneManager.reload_current_scene()

func quit_to_menu():
	SceneManager.load_scene("res://scenes/main_menu.tscn")
